export const environment = {
    production: false,
    base_url:"https://localhost:44384/api"
  };