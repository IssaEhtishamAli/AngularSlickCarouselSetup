import { Routes } from '@angular/router';
import { AdminComponent } from './Auth/admin/admin.component';
import { SignInComponent } from './Auth/sign-in/sign-in.component';
import { LayoutComponent } from './Layout/layout/layout.component';
import { AuthGuard } from './AuthGuard/auth.guard';

export const routes: Routes = [
    {path:'',pathMatch:'full',redirectTo:'sign-in'},
    {path:'sign-in',component:SignInComponent},
    {path:'admin',loadComponent: ()=> import('./Auth/admin/admin.component').then(c=>c.AdminComponent)},
    {
        path:'hidayah',
        component:LayoutComponent,
        // canActivate: [AuthGuard],
        children:[
            {
                path:'home',
                loadComponent: () =>
                    import('./Modules/holy-quran/hidayah-home/hidayah-home.component').then(c=>c.HidayahHomeComponent),
            },
            {
                path:'holyQuran',
                loadComponent: ()=>
                    import('./Modules/holy-quran/hidayah-quran/hidayah-quran.component').then(c=>c.HidayahQuranComponent)
            },
            {
                path:'nooraniPrimer',
                loadComponent: ()=>
                    import('./Modules/holy-quran/hidayah-noorani-primer/hidayah-noorani-primer.component').then(c=>c.HidayahNooraniPrimerComponent)
            },
            {
                path:'practiceBoard',
                loadComponent: ()=>
                    import('./Modules/holy-quran/hidayah-practice-board/hidayah-practice-board.component').then(c=>c.HidayahPracticeBoardComponent)
            }
        ]
    }
];
