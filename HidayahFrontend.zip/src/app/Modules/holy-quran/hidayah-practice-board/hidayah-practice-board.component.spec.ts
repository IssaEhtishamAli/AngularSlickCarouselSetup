import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HidayahPracticeBoardComponent } from './hidayah-practice-board.component';

describe('HidayahPracticeBoardComponent', () => {
  let component: HidayahPracticeBoardComponent;
  let fixture: ComponentFixture<HidayahPracticeBoardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HidayahPracticeBoardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HidayahPracticeBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
